package br.com.itau.dojo.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.dojo.dto.CreateUpdateTransacaoDTO;
import br.com.itau.dojo.dto.TransacaoDTO;
import br.com.itau.dojo.service.TransacaoService;

@RestController
@RequestMapping("transacoes")
public class TransacaoController {
	private TransacaoService transacaoService;

    public TransacaoController(TransacaoService transacaoService){
        this.transacaoService = transacaoService;
    }
    
    /*
    @GetMapping
    public List<ContaDTO> getContaPorId(@PathVariable(name = "idConta") Integer idConta){
        return contaService.getContaPorId(idConta);
    }
    */
    
    @GetMapping
    public List getTransacoes(){
        return (List<TransacaoDTO>) transacaoService.getTransacoes();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TransacaoDTO incluirTransacao (@RequestBody CreateUpdateTransacaoDTO createUpdateTransacaoDTO){
        return transacaoService.incluirTransacao(createUpdateTransacaoDTO);
    }


}
