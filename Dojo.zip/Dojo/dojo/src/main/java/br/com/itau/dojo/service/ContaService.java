package br.com.itau.dojo.service;

import java.util.List;

import br.com.itau.dojo.dto.ContaDTO;
import br.com.itau.dojo.dto.CreateUpdateContaDTO;
import br.com.itau.dojo.entity.ContaEntity;

public interface ContaService {
	//List<ContaDTO> getContaPorId (Integer Id);
	List<ContaDTO> getContas ();
    ContaDTO incluirConta(CreateUpdateContaDTO createUpdateContaDTO);
}
