package br.com.itau.dojo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import br.com.itau.dojo.dto.CreateUpdateContaDTO;
import br.com.itau.dojo.dto.CreateUpdateTipoOperacaoDTO;
import br.com.itau.dojo.dto.TipoOperacaoDTO;
import br.com.itau.dojo.entity.ContaEntity;
import br.com.itau.dojo.entity.TipoOperacaoEntity;
import br.com.itau.dojo.repository.ContaRepository;
import br.com.itau.dojo.repository.TipoOperacaoRepository;

@Service
public class TipoOperacaoServiceImpl implements TipoOperacaoService {
    private TipoOperacaoRepository tipoOperacaoRepository;

    public TipoOperacaoServiceImpl(TipoOperacaoRepository tipoOperacaoRepository){
        this.tipoOperacaoRepository = tipoOperacaoRepository;
    }
    
    /*
    @Override
    public List<ContaDTO> getContaPorId(Integer id) {
        return contaRepository.getContaPorId(id);
                //.stream()
                //.map(entity -> {
                //    ContaDTO dto = new ContaDTO();
                //    dto.setNumeroConta(entity.getNumeroConta());
                //    return dto;
                //}).collect(Collectors.toList());
    }
	*/
    
    @Override
    public TipoOperacaoDTO incluirTipoOperacao(CreateUpdateTipoOperacaoDTO createUpdateTipoOperacaoDTO) {
        TipoOperacaoEntity entity = new TipoOperacaoEntity();
        entity.setIdTipoOperacao(createUpdateTipoOperacaoDTO.getIdTipoOperacao());
        entity.setDescricaoTipoOperacao(createUpdateTipoOperacaoDTO.getDescricaoTipoOperacao());

        TipoOperacaoEntity savedEntity = tipoOperacaoRepository.save(entity);

        TipoOperacaoDTO dto = new TipoOperacaoDTO();
        dto.setidTipoOperacao(savedEntity.getIdTipoOperacao());
        dto.setDescricaoTipoOperacao(savedEntity.getDescricaoTipoOperacao());

        return dto;
    }

	@Override
    public List<TipoOperacaoDTO> getTiposOperacoes() {
        return tipoOperacaoRepository.findAll()
                .stream()
                .map(entity -> {
                    TipoOperacaoDTO dto = new TipoOperacaoDTO();
                    dto.setidTipoOperacao(entity.getIdTipoOperacao());
                    dto.setDescricaoTipoOperacao(entity.getDescricaoTipoOperacao());
                    return dto;
                }).collect(Collectors.toList());
    }
}
