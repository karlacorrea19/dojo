package br.com.itau.dojo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import br.com.itau.dojo.dto.CreateUpdateTransacaoDTO;
import br.com.itau.dojo.dto.TransacaoDTO;
import br.com.itau.dojo.entity.TransacaoEntity;
import br.com.itau.dojo.repository.TransacaoRepository;

@Service
public class TransacaoServiceImpl implements TransacaoService{
    private TransacaoRepository transacaoRepository;

    public TransacaoServiceImpl(TransacaoRepository transacaoRepository){
        this.transacaoRepository = transacaoRepository;
    }
    
    /*
    @Override
    public List<ContaDTO> getContaPorId(Integer id) {
        return contaRepository.getContaPorId(id);
                //.stream()
                //.map(entity -> {
                //    ContaDTO dto = new ContaDTO();
                //    dto.setNumeroConta(entity.getNumeroConta());
                //    return dto;
                //}).collect(Collectors.toList());
    }
	*/
    
    @Override
    public TransacaoDTO incluirTransacao(CreateUpdateTransacaoDTO createUpdateTransacaoDTO) {
        TransacaoEntity entity = new TransacaoEntity();
        entity.setIdConta(createUpdateTransacaoDTO.getIdConta());
        entity.setIdTipoOperacao(createUpdateTransacaoDTO.getIdTipoOperacao());
        entity.setValor(createUpdateTransacaoDTO.getValor());
        entity.setDataHora(createUpdateTransacaoDTO.getDataHora());

        TransacaoEntity savedEntity = transacaoRepository.save(entity);

        TransacaoDTO dto = new TransacaoDTO();
        dto.setIdTransacao(savedEntity.getIdTransacao());
        dto.setIdConta(savedEntity.getIdConta());
        //dto.getIdTipoOperacao(savedEntity.getIdTipoOperacao());   ERRO
        dto.setValor(savedEntity.getValor());  // VALOR NEGATIVO PARA TIPO DE OPERACAO = ????
        dto.setDataHora(savedEntity.getDataHora());

        return dto;
    }

	@Override
    public List<TransacaoDTO> getTransacoes() {
        return transacaoRepository.findAll()
                .stream()
                .map(entity -> {
                    TransacaoDTO dto = new TransacaoDTO();
                    dto.setIdTransacao(entity.getIdTransacao());
                    dto.setIdConta(entity.getIdConta());
                    dto.setIdTipoOperacao(entity.getIdTipoOperacao());
                    dto.setValor(entity.getValor());
                    dto.setDataHora(entity.getDataHora());
                    return dto;
                }).collect(Collectors.toList());
    }

}
