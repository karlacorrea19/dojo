package br.com.itau.dojo.dto;

public class CreateUpdateTransacaoDTO {
    private int idTransacao;
    private int idConta;
    private int idTipoOperacao;
    private String valor;
    private String dataHora;

    public int getIdTransacao() {
        return idTransacao;
    }

    public void setIdTransacao(Integer idTransacao) {
        this.idTransacao = idTransacao;
    }

    public int getIdConta() {
        return idConta;
    }

    public void setIdConta(Integer idConta) {
        this.idConta = idConta;
    }

    public int getIdTipoOperacao() {
        return idTipoOperacao;
    }

    public void setIdTipoOperacao(Integer idConta) {
        this.idTipoOperacao = idTipoOperacao;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getDataHora() {
        return dataHora;
    }

    public void setDataHora(String dataHora) {
        this.dataHora = dataHora;
    }

}
