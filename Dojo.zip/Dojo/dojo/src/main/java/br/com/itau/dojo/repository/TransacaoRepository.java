package br.com.itau.dojo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.com.itau.dojo.entity.TransacaoEntity;

public interface TransacaoRepository extends JpaRepository<TransacaoEntity, Integer>{
    List<TransacaoEntity> findAll();

    @Query(value = "from TransacaoEntity")
    List<TransacaoEntity> listar();

}
