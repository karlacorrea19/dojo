package br.com.itau.dojo.dto;

public class CreateUpdateTipoOperacaoDTO {
    private int idTipoOperacao;
    private String descricaoTipoOperacao;

    public int getIdTipoOperacao() {
        return idTipoOperacao;
    }

    public void setidTipoOperacao(Integer idTipoOperacao) {
        this.idTipoOperacao = idTipoOperacao;
    }

    public String getDescricaoTipoOperacao() {
        return descricaoTipoOperacao;
    }

    public void setDescricaoTipoOperacao(String descricaoTipoOperacao) {
        this.descricaoTipoOperacao = descricaoTipoOperacao;
    }

}
