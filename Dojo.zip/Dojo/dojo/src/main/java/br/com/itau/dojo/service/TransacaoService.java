package br.com.itau.dojo.service;

import java.util.List;

import br.com.itau.dojo.dto.CreateUpdateTransacaoDTO;
import br.com.itau.dojo.dto.TransacaoDTO;

public interface TransacaoService {
	//List<ContaDTO> getContaPorId (Integer Id);
	List<TransacaoDTO> getTransacoes ();
	TransacaoDTO incluirTransacao(CreateUpdateTransacaoDTO createUpdateTransacaoDTO);
}
