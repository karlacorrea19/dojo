package br.com.itau.dojo.dto;

public class TransacaoDTO {
    private Integer idTransacao;
    private Integer idConta;
    private Integer idTipoOperacao;
    private String valor;
    private String dataHora;

    public Integer getIdTransacao() {
        return idTransacao;
    }

    public void setIdTransacao(Integer idTransacao) {
        this.idTransacao = idTransacao;
    }

    public Integer getIdConta() {
        return idConta;
    }

    public void setIdConta(Integer idConta) {
        this.idConta = idConta;
    }

    public Integer getIdTipoOperacao() {
        return idTipoOperacao;
    }

    public void setIdTipoOperacao(Integer idTipoOperacao) {
        this.idTipoOperacao = idTipoOperacao;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getDataHora() {
        return dataHora;
    }

    public void setDataHora(String dataHora) {
        this.dataHora = dataHora;
    }
}
