package br.com.itau.dojo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.com.itau.dojo.entity.TipoOperacaoEntity;

public interface TipoOperacaoRepository extends JpaRepository<TipoOperacaoEntity, Integer>{
    List<TipoOperacaoEntity> findAll();

    @Query(value = "from TipoOperacaoEntity")
    List<TipoOperacaoEntity> listar();

}
