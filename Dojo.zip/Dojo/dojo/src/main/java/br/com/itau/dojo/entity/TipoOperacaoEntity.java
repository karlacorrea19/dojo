package br.com.itau.dojo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_tipo_operacao")
public class TipoOperacaoEntity {
    @Id
    private Integer idTipoOperacao;

    @Column
    private String descricaoTipoOperacao;
    
    public Integer getIdTipoOperacao() {
        return idTipoOperacao;
    }

    public void setIdTipoOperacao(Integer idTipoOperacao) {
        this.idTipoOperacao = idTipoOperacao;
    }

    public String getDescricaoTipoOperacao() {
        return descricaoTipoOperacao;
    }

    public void setDescricaoTipoOperacao(String descricaoTipoOperacao) {
        this.descricaoTipoOperacao = descricaoTipoOperacao;
    }
    
}
