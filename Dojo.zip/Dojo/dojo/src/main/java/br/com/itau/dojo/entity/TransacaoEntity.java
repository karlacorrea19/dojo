package br.com.itau.dojo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_transacao")
public class TransacaoEntity {
	@Id
	@Column(name = "id_transacao")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer idTransacao;
	
	@ManyToOne
	@JoinColumn (name = "id_conta")
	private Integer idConta;
	
	@ManyToOne
	@JoinColumn (name = "id_tipo_operacao")
	private Integer idTipoOperacao;
	
	@Column (name = "valor")
	private String valor;
	
	@Column (name = "data_hora")
	private String dataHora;
	
	public Integer getIdTransacao() {
	    return idTransacao;
	}
	
	public void setIdTransacao(Integer idTransacao) {
	    this.idTransacao = idTransacao;
	}
	
	public Integer getIdConta() {
	    return idConta;
	}
	
	public void setIdConta(Integer idConta) {
	    this.idConta = idConta;
	}
	
	public Integer getIdTipoOperacao() {
	    return idTipoOperacao;
	}
	
	public void setIdTipoOperacao(Integer idTipoOperacao) {
	    this.idTipoOperacao = idTipoOperacao;
	}
	
	public String getValor() {
	    return valor;
	}
	
	public void setValor(String valor) {
	    this.valor = valor;
	}
	
	public String getDataHora() {
	    return dataHora;
	}
	
	public void setDataHora(String dataHora) {
	    this.dataHora = dataHora;
	}
}
