package br.com.itau.dojo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.com.itau.dojo.entity.ContaEntity;

public interface ContaRepository extends JpaRepository<ContaEntity, Integer>{
    List<ContaEntity> findAll();

    @Query(value = "from ContaEntity")
    List<ContaEntity> listar();
}
