package br.com.itau.dojo.service;

import java.util.List;

import br.com.itau.dojo.dto.CreateUpdateTipoOperacaoDTO;
import br.com.itau.dojo.dto.TipoOperacaoDTO;

public interface TipoOperacaoService {
	List<TipoOperacaoDTO> getTiposOperacoes();
    TipoOperacaoDTO incluirTipoOperacao(CreateUpdateTipoOperacaoDTO createUpdateTipoOperacaoDTO);
}
