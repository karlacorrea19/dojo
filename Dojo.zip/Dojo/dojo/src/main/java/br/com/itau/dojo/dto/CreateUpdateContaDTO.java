package br.com.itau.dojo.dto;

public class CreateUpdateContaDTO {
    private String numeroConta;

    public String getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(String numeroConta) {
        this.numeroConta = numeroConta;
    }

}
