package br.com.itau.dojo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import br.com.itau.dojo.dto.ContaDTO;
import br.com.itau.dojo.dto.CreateUpdateContaDTO;
import br.com.itau.dojo.entity.ContaEntity;
import br.com.itau.dojo.repository.ContaRepository;

@Service
public class ContaServiceImpl implements ContaService {

    private ContaRepository contaRepository;

    public ContaServiceImpl(ContaRepository contaRepository){
        this.contaRepository = contaRepository;
    }
    
    /*
    @Override
    public List<ContaDTO> getContaPorId(Integer id) {
        return contaRepository.getContaPorId(id);
                //.stream()
                //.map(entity -> {
                //    ContaDTO dto = new ContaDTO();
                //    dto.setNumeroConta(entity.getNumeroConta());
                //    return dto;
                //}).collect(Collectors.toList());
    }
	*/
    
    @Override
    public ContaDTO incluirConta(CreateUpdateContaDTO createUpdateContaDTO) {
        ContaEntity entity = new ContaEntity();
        entity.setNumeroConta(createUpdateContaDTO.getNumeroConta());

        ContaEntity savedEntity = contaRepository.save(entity);

        ContaDTO dto = new ContaDTO();
        dto.setIdConta(savedEntity.getIdConta());
        dto.setNumeroConta(savedEntity.getNumeroConta());

        return dto;
    }

	@Override
    public List<ContaDTO> getContas() {
        return contaRepository.findAll()
                .stream()
                .map(entity -> {
                    ContaDTO dto = new ContaDTO();
                    dto.setIdConta(entity.getIdConta());
                    dto.setNumeroConta(entity.getNumeroConta());
                    return dto;
                }).collect(Collectors.toList());
    }
}