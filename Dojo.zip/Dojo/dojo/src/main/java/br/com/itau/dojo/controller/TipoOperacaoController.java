package br.com.itau.dojo.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.dojo.dto.CreateUpdateTipoOperacaoDTO;
import br.com.itau.dojo.dto.TipoOperacaoDTO;
import br.com.itau.dojo.service.TipoOperacaoService;

@RestController
@RequestMapping("operacoes")
public class TipoOperacaoController {
	private TipoOperacaoService tipoOperacaoService;

    public TipoOperacaoController(TipoOperacaoService tipoOperacaoService){
        this.tipoOperacaoService = tipoOperacaoService;
    }
    
    /*
    @GetMapping
    public List<ContaDTO> getContaPorId(@PathVariable(name = "idConta") Integer idConta){
        return contaService.getContaPorId(idConta);
    }
    */
    
    @GetMapping
    public List getTiposOperacoes(){
        return (List<TipoOperacaoDTO>) tipoOperacaoService.getTiposOperacoes();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TipoOperacaoDTO incluirTipoOperacao (@RequestBody CreateUpdateTipoOperacaoDTO createUpdateTipoOperacaoDTO){
        return tipoOperacaoService.incluirTipoOperacao(createUpdateTipoOperacaoDTO);
    }

}
